// Run with:  node --test route-checker.test.mjs
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRouteChecker } from './route-checker.js';

const A = { id: 'A', x: 100, y: 500, r: 30 };
const B = { id: 'B', x: 120, y: 400, r: 30 };
const C = { id: 'C', x: 140, y: 300, r: 30 };
const X = { id: 'X', x: 300, y: 400, r: 30 }; // not in the route

// Simulate a hand held on `hold` from t0 for `ms`, frame every 33 ms.
function hold(checker, h, t0, ms) {
  const events = [];
  for (let t = t0; t <= t0 + ms; t += 33) events.push(...checker.update([{ x: h.x, y: h.y }], t));
  return events;
}
const away = (checker, t) => checker.update([{ x: 0, y: 0 }], t);

test('correct holds in order give correct, correct, top', () => {
  const c = createRouteChecker({ route: [A, B, C], allHolds: [A, B, C, X] });
  assert.deepEqual(hold(c, A, 0, 500).map((e) => e.type), ['correct']);
  away(c, 700);
  assert.deepEqual(hold(c, B, 1000, 500).map((e) => e.type), ['correct']);
  away(c, 1700);
  assert.deepEqual(hold(c, C, 2000, 500).map((e) => e.type), ['top']);
  assert.equal(c.done, true);
});

test('a quick touch shorter than the dwell time does nothing', () => {
  const c = createRouteChecker({ route: [A, B] });
  assert.deepEqual(hold(c, A, 0, 200), []);
});

test('grabbing a non-route hold is wrong, once per touch', () => {
  const c = createRouteChecker({ route: [A, B], allHolds: [A, B, X] });
  assert.deepEqual(hold(c, X, 0, 2000).map((e) => e.type), ['wrong']);
  away(c, 2300);
  assert.deepEqual(hold(c, X, 2500, 600).map((e) => e.type), ['wrong']);
});

test('skipping ahead in the route is wrong', () => {
  const c = createRouteChecker({ route: [A, B, C] });
  assert.deepEqual(hold(c, C, 0, 500).map((e) => e.type), ['wrong']);
  assert.equal(c.nextIndex, 0);
});

test('resting on an already climbed hold is silent', () => {
  const c = createRouteChecker({ route: [A, B, C] });
  hold(c, A, 0, 500);
  away(c, 700);
  assert.deepEqual(hold(c, A, 1000, 800), []);
  assert.equal(c.nextIndex, 1);
});

test('short tracking drop-outs do not restart the dwell timer', () => {
  const c = createRouteChecker({ route: [A], dwellMs: 400, graceMs: 150 });
  c.update([{ x: A.x, y: A.y }], 0);
  c.update([], 100);                 // lost for one frame
  const ev = c.update([{ x: A.x, y: A.y }], 450);
  assert.deepEqual(ev.map((e) => e.type), ['top']);
});

test('reset starts the route again', () => {
  const c = createRouteChecker({ route: [A, B] });
  hold(c, A, 0, 500);
  c.reset();
  assert.equal(c.nextIndex, 0);
  away(c, 600);
  assert.deepEqual(hold(c, A, 700, 500).map((e) => e.type), ['correct']);
});
