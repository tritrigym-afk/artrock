// route-checker.js
// Pure logic, no browser APIs: decides when a hand "grabs" a hold and whether
// that grab is the correct next hold of the route. Easy to unit-test.
//
// Coordinates: holds and points must use the SAME pixel space
// (the video frame: 0..video.videoWidth, 0..video.videoHeight).
//
// Hold:  { id: string, x: number, y: number, r: number }   (r = radius in px)
// Point: { x: number, y: number }                           (a tracked hand/foot)
//
// Events returned by update():
//   { type: 'correct', hold, index }   next route hold grabbed (index = 0-based)
//   { type: 'top', hold, index }       last route hold grabbed -> route done
//   { type: 'wrong', hold }            a hold that is not the next one was grabbed

export function createRouteChecker({
  route,                // array of holds, in climbing order
  allHolds = route,     // every known hold (route + others) – used to detect wrong grabs
  dwellMs = 400,        // how long a hand must stay on a hold to count as a grab
  graceMs = 150,        // tolerate short tracking drop-outs before a touch ends
} = {}) {
  if (!Array.isArray(route) || route.length === 0) {
    throw new Error('createRouteChecker: route must be a non-empty array of holds');
  }

  // Make sure every route hold is also in allHolds (by id).
  const holdsById = new Map();
  for (const h of [...allHolds, ...route]) holdsById.set(h.id, h);
  const holds = [...holdsById.values()];
  const routeIndex = new Map(route.map((h, i) => [h.id, i]));

  let next = 0;
  // id -> { start, lastSeen, fired }
  const touches = new Map();

  function isTouching(hold, points) {
    return points.some((p) => Math.hypot(p.x - hold.x, p.y - hold.y) <= hold.r);
  }

  function update(points, now) {
    const events = [];
    if (next >= route.length) return events; // route finished

    for (const hold of holds) {
      const touching = isTouching(hold, points);
      let t = touches.get(hold.id);

      if (!touching) {
        if (t && now - t.lastSeen > graceMs) touches.delete(hold.id);
        continue;
      }

      if (!t) {
        t = { start: now, lastSeen: now, fired: false };
        touches.set(hold.id, t);
      }
      t.lastSeen = now;

      if (t.fired || now - t.start < dwellMs) continue;

      const idx = routeIndex.get(hold.id);
      // Resting on a hold you already climbed is fine – no sound.
      if (idx !== undefined && idx < next) { t.fired = true; continue; }

      t.fired = true; // one event per touch; the hand must leave to trigger again
      if (idx === next) {
        next++;
        events.push({ type: next === route.length ? 'top' : 'correct', hold, index: idx });
        if (next === route.length) break;
      } else {
        events.push({ type: 'wrong', hold });
      }
    }
    return events;
  }

  function reset() {
    next = 0;
    touches.clear();
  }

  return {
    update,
    reset,
    get nextIndex() { return next; },
    get nextHold() { return route[next] ?? null; },
    get done() { return next >= route.length; },
  };
}
