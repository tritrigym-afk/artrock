# Motion Coach – Project Ascent (ART ROCK)

Browser body tracking for the spray-wall app. The climber sets a route by tapping holds; while climbing, the app plays a **ding** when the correct next hold is grabbed and says **"Wrong hold"** when another hold is grabbed. The last hold plays a "Top! Well done" chime.

## Files

| File | What it does |
|---|---|
| `route-checker.js` | Pure logic (no browser APIs): grab detection (hand stays on a hold ≥ 400 ms), correct / wrong / top events. Unit-tested. |
| `route-checker.test.mjs` | 7 Node tests: `npm test` |
| `motion-coach.js` | Camera (`getUserMedia`), MediaPipe Pose Landmarker (GPU → CPU fallback), Web Audio ding/buzz, speech, and `createMotionCoach()` that ties it together. |
| `index.html` | Working demo: start camera → tap route holds → Start climbing. ART ROCK styling. |

## Run it

```bash
npm test             # logic tests
npm start            # serves on http://localhost:8080 (needs Node; or: python3 -m http.server 8080)
```

The camera only works on **HTTPS or localhost**. To try it on a phone, deploy the folder to any HTTPS static host (Netlify, Vercel, GitHub Pages) or tunnel the local server (e.g. `npx localtunnel --port 8080`).

## How it works

1. Phone on a tripod facing the wall, the whole climber in view. **Don't move it** after setting the route.
2. Hold coordinates are stored in **video pixels**. Because the route is set on the same fixed camera view, holds and body points line up without any perspective maths.
3. MediaPipe gives 33 body points per frame. Used: index fingers (19, 20) and wrists (15, 16); feet (31, 32) optional.
4. A hand inside a hold's circle for 400 ms = a grab. Next route hold → ding. Any other hold (non-route, or a route hold out of order) → "Wrong hold". Resting on a hold already climbed is silent. One event per touch.

## Use it in the app

```js
import { loadPose, startCamera, createSounds, createMotionCoach } from './motion-coach.js';

const pose = await loadPose();
const sounds = createSounds();
button.onclick = async () => {
  sounds.unlock();                       // must be inside a tap (phones block audio otherwise)
  await startCamera(videoEl);
  const coach = createMotionCoach({
    pose, video: videoEl, sounds,
    route,                               // [{ id, x, y, r }] in video pixels, climbing order
    allHolds,                            // route + all other detected holds
    onEvent: (ev) => console.log(ev.type, ev.hold),   // 'correct' | 'top' | 'wrong'
    onFrame: (f) => drawOverlay(f),      // landmarks, points, fps
  });
  coach.start();
};
```

If the route comes from a different photo (e.g. a high-res upload), the hold coordinates must first be mapped onto the video frame, using the 3–4 reference points and a homography (OpenCV.js `getPerspectiveTransform`). Not built yet.

## Known limits / next steps

- **Wooden mannequin:** MediaPipe is trained on people and may not detect the test-rig mannequin. Test this first. Fallback: coloured tape on the mannequin's hands + colour tracking.
- Climber seen from behind: left/right can swap. Harmless, because either hand counts.
- Tested: logic unit tests pass; demo loads, model loads, camera starts, holds can be tapped and climbing mode runs in headless Chromium with a fake camera. **Not yet tested with a real climber or on a real phone.**
- `@mediapipe/tasks-vision@0.10.14` and the `pose_landmarker_lite` model are loaded from CDNs; `MEDIAPIPE.modelFull` is more accurate but slower.

## Handoff for Claude Code

Open this folder in Claude Code and start with something like:

> Read README.md. Integrate motion-coach.js into our web app at [path/framework]. The route data comes from [where your app stores selected holds]. Keep route-checker.js tests passing.
